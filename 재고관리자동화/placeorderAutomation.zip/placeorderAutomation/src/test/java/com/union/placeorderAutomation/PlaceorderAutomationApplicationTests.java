package com.union.placeorderAutomation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaceorderAutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}

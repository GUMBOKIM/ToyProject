package com.union.placeorderAutomation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaceorderAutomationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaceorderAutomationApplication.class, args);
	}

}
